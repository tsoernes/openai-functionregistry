# OpenAI Function Registry

A function registry to interact with the OpenAI Chat client function (tool) calling API.

See usage example.

`poetry install`
